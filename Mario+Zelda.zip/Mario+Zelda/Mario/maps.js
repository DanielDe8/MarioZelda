const spawnLevel = 1 // // level, na kterem se zacina

const maps = [ // mapy levlu
    [
      '                                      ',
      '                                      ',
      '                                      ',
      '                                      ',
      '                                      ',
      '     %   =*=%=                        ',
      '                                      ',
      '                            -+        ',
      '                    ^   ^   ()        ',
      '==============================   =====',
    ],
    [
      '£                                       £',
      '£                                       £',
      '£                                       £',
      '£                                       £',
      '£                                       £',
      '£        @@@@@m              xxx        £',
      '£                          x x x        £',
      '£                        x x x x  x   -+£',
      '£               z   z  x x x x x  x   ()£',
      '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',
    ]
]

/*

=: blok
$: coin
%: box (s coinem)
*: box (se zvetsujici houbou),
}: otevreny box
(: leva spodni cast trubky
): prava spodni cast trubky
-: leva horni cast trubky
+: prava horni cast trubky
^: houba nepratel (znici ji skoceni na hlavu)
#: zvetsujici houba
!: modry blok
£: modre cihly
z: modra houba nepratel
@: modry box (s coinem)
m: modry box (se zvetsujici houbou)
x: modry kov

Predloha pro vecinu cervenych map:

[
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '                                      ',
    '======================================',
],

Predloha pro vecinu modrych map:

[
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '£                                       £',
    '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!',
],

*/