const spawnLevel = 1 // level, na kterem se zacina

const maps = [ // mapy levlu
    [
        'yccccccccw',
        'a@      $b',
        'a        b',
        'a        b',
        'a        b',
        'a        b',
        'a        b',
        'a       $b',
        'xddddddddz',
    ],
    [
        'ycc)cc^ccw',
        'a        b',
        'a      * b',
        'a    (   b',
        '%        b',
        'a    (   b',
        'a   *    b',
        'a        b',
        'xdd)dd)ddz',
    ],
    [
        'yccccccccw',
        'a        b',
        ')        )',
        'a        b',
        'a        b',
        'a    $   b',
        ')   }    )',
        'a        b',
        'xddddddddz',
    ],
]

/*
    a: leva stena
    b: prava stena
    c: horni stena
    d: spodni stena
    w: stena horniho pravero rohu
    x: stena dolniho leveho rohu
    y: stena horniho leveho rohu
    z: stena dolniho pravero rohu
    %: leve dvere (posouvaji o level)
    ^: horni dvere (posouvaji o level)
    $: schody (posouvaji o level)
    *: slicer (nepratel, neznicitelny, pohibuje se horizontalne)
    }: skeletors (nepratel, znicitelny, pohibuje se vertikalne)
    ): lucerny (nic, jako stena)
    (: krb (nic, jako stena)
    @: dira (posouva o level)
    (mezera): nic
*/

/*
Predloha pro vecinu map:

[
    'yccccccccw',
    'a        b',
    'a        b',
    'a        b',
    'a        b',
    'a        b',
    'a        b',
    'a       $b',
    'xddddddddz',
],
*/